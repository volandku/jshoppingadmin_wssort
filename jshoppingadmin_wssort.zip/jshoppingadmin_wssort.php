<?php
defined('_JEXEC') or die('Restricted access');


class plgSystemJshoppingadmin_wssort extends JPlugin{

	protected $app;

	public function onAfterRoute()
	{

		if ($this->app->isAdmin()) return;
		$jsconfig = JSFactory::getConfig();

		$jsconfig->sorting_products_field_s_select[7] = 'pr_cat.product_ordering';
		$jsconfig->sorting_products_name_s_select[7] = JText::_('_JSHOP_SORT_MANUAL');


	}

	

}